//
//  ViewController.swift
//  MyNotebook
//
//  Created by Tina Thomsen on 27/02/2020.
//  Copyright © 2020 Tina Thomsen. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
	
	var startNote = "..."
	var notes = [String]()
	var currentRow = -1 //no edit
	let fileName = "Notes.txt"
	
	var persistantNotes: [NSManagedObject] = []
	
	@IBOutlet weak var label: UILabel!
	@IBOutlet weak var myNote: UITextView!
	@IBOutlet weak var notebookoverview: UITableView!
	
	override func viewDidLoad() {
		super.viewDidLoad()
		
		notes.append("Test Note")
		notebookoverview.dataSource = self
		notebookoverview.delegate = self
	}
	
	override func viewWillAppear(_ animated: Bool) {
		myNote.text = startNote
		super.viewWillAppear(animated)
		guard let appDelegate =  UIApplication.shared.delegate as? AppDelegate else{
			return
		}
		
		let managedContext = appDelegate.persistentContainer.viewContext
		let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Note")
		
		do{
			persistantNotes = try managedContext.fetch(fetchRequest)
		}catch let error as NSError{
			print("From viewWillAppear: Couldn't fetch \(error), \(error.userInfo)")
		}
	}
	
	@IBAction func addNote(_ sender: UIButton) {
		
		let alert = UIAlertController(title: "New note", message: "New note was added", preferredStyle: .alert)
		let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] action in
			guard let text = alert.textFields?.first, let noteToSave = text.text
				else{
					return
			}
			self.saveNote(note: noteToSave)
			self.notebookoverview.reloadData()
		}
		
		let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
		alert.addTextField()
		alert.addAction(saveAction)
		alert.addAction(cancelAction)
		
		present(alert, animated: true)
	}
	
	func saveNote(note: String){
		//to avoid crashes
		//Makes sure that appDelegate is usable variable w/o trouble
		//Otherwise function would not work
		guard let appDelegate =  UIApplication.shared.delegate as?
			AppDelegate else{
				return
		}
		
		let managedContext = appDelegate.persistentContainer.viewContext
		let entity = NSEntityDescription.entity(forEntityName: "Note", in: managedContext)!
		
		let noteToSave = NSManagedObject(entity: entity, insertInto: managedContext)
		noteToSave.setValue(note, forKey: "content")
		
		do {
			try managedContext.save()
			persistantNotes.append(noteToSave)
		} catch let error as NSError{
			print("Couldn't save \(error), \(error.userInfo)")
		}
		
	}
	
	//TABLEVIEW
	func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return persistantNotes.count
	}
	
	func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

	  let note = persistantNotes[indexPath.row]
	  let cell = notebookoverview.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
	  cell.textLabel?.text = note.value(forKeyPath: "content") as? String
	  return cell
	}
	
	func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
		//edit a note - located in tableview
		print("To Note at: \(indexPath.row)")
		currentRow = indexPath.row
		
		tableView.deselectRow(at: indexPath, animated: true)
	}
}
	
	/*
	func getDocDir() -> URL{
		//locate document folder, return first element in document folder
		let docDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
		return docDir[0]
	}
	
	func readFileNote(fileName: String) -> String{
		let filePath = getDocDir().appendingPathComponent(fileName)
		print(filePath)
		
		do{
			let content = try String(contentsOf: filePath, encoding: .utf8)
			return content
		}catch{
			print("An error was caught while trying to read file " + fileName)
		}
		return "Empty"
	}
	
	func saveFileNote(str:String, fileName: String){
		let filePath = getDocDir().appendingPathComponent(fileName)
		do {
			try str.write(to: filePath, atomically: true, encoding: .utf8)
			print("Write to notes \(str)")
		}catch {
			print("An error was caught while trying to write to notes: \(str)")
		}
	}*/

//SAVEBTN
/*startNote = myNote.text
if currentRow > -1{
	notes[currentRow] = startNote
	currentRow = -1
	//If no notes saved prior, set current note to start note, and don't add
}else{
	notes.append(myNote.text) //add note to notes array
}
notebookoverview.reloadData() //readying for new note
myNote.text = "..."*/

//CELL RETURN
/*func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
	//return reuseable table-view cell obj or the if none, the first cell in tableview
	if let cell = notebookoverview.dequeueReusableCell(withIdentifier: "cell1") {
		cell.textLabel?.text = notes[indexPath.row]
		return cell
	}else{
		return UITableViewCell()
	}
}*/
